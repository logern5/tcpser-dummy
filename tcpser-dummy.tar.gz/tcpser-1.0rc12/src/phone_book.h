int pb_init(void);
int pb_add(unsigned char* from,unsigned char* to);
unsigned char* pb_search(unsigned char *number);

