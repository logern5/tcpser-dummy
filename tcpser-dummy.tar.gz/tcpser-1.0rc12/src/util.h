int writePipe(int fd,unsigned char msg);
int writeFile(unsigned char* name, int fd);

